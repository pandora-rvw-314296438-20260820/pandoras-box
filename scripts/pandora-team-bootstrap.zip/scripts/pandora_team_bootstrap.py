from __future__ import annotations

from pathlib import Path
import re
import shutil
import subprocess
import textwrap
import json

ROOT = Path.cwd()
if not (ROOT / '.git').exists():
    raise SystemExit('run from the repository root')

# Apply the previously validated live-backend source parity patch first.
patch = ROOT / 'scripts/pandora-user-admin-source-parity.patch'
if not patch.exists():
    raise SystemExit('backend source-parity patch is missing')
else:
    check = subprocess.run(['git', 'apply', '--check', str(patch)], cwd=ROOT, capture_output=True, text=True)
    if check.returncode == 0:
        subprocess.run(['git', 'apply', str(patch)], cwd=ROOT, check=True)
    else:
        # It may already be partially present. Only continue if all key files exist.
        required = [
            ROOT / 'supabase/functions/pandora-user-admin/index.ts',
            ROOT / 'supabase/functions/pandora-user-admin/deno.json',
        ]
        if not all(p.exists() for p in required):
            raise SystemExit('source parity patch does not apply and required backend files are absent:\n' + check.stderr)

mobile = ROOT / 'apps/pandora-mobile'
pubspec = mobile / 'pubspec.yaml'
pub = pubspec.read_text()
package_match = re.search(r'^name:\s*([A-Za-z0-9_]+)\s*$', pub, re.M)
if not package_match:
    raise SystemExit('Could not determine Flutter package name')
package_name = package_match.group(1)

# The app already uses Supabase in canonical builds. Add the dependency only if recovery source omitted it.
if not re.search(r'^\s{2}supabase_flutter\s*:', pub, re.M):
    deps_match = re.search(r'(^dependencies:\s*$)', pub, re.M)
    if not deps_match:
        raise SystemExit('pubspec dependencies section missing')
    # Place after flutter SDK dependency block when possible.
    flutter_block = re.search(r'(^dependencies:\s*\n\s{2}flutter:\s*\n\s{4}sdk:\s*flutter\s*\n)', pub, re.M)
    if flutter_block:
        insert_at = flutter_block.end()
        pub = pub[:insert_at] + '  supabase_flutter: ^2.9.1\n' + pub[insert_at:]
    else:
        insert_at = deps_match.end()
        pub = pub[:insert_at] + '\n  supabase_flutter: ^2.9.1' + pub[insert_at:]
    pubspec.write_text(pub)

# Ship the Team feature as a distinct owner-test release.
pub = pubspec.read_text()
pub, version_count = re.subn(
    r'^version:\s*\S+\s*$',
    'version: 0.3.0-rc.3+6',
    pub,
    count=1,
    flags=re.M,
)
if version_count != 1:
    raise SystemExit('pubspec version anchor missing')
pubspec.write_text(pub)

config_file = mobile / 'lib/pandora_config.dart'
config_text = config_file.read_text()
config_text, config_version_count = re.subn(
    r"defaultValue:\s*'0\.3\.0-rc\.2\+5'",
    "defaultValue: '0.3.0-rc.3+6'",
    config_text,
    count=1,
)
if config_version_count != 1:
    raise SystemExit('PandoraConfig version anchor missing')
config_file.write_text(config_text)

workflow_file = ROOT / '.github/workflows/pandora-mobile-integration.yml'
workflow_text = workflow_file.read_text()
workflow_text = workflow_text.replace(
    "EXPECTED_APP_VERSION: '0.3.0-rc.2+5'",
    "EXPECTED_APP_VERSION: '0.3.0-rc.3+6'",
)
workflow_text = workflow_text.replace(
    "grep -Fq \"versionCode='5'\" \"$evidence/badging.txt\"",
    "grep -Fq \"versionCode='6'\" \"$evidence/badging.txt\"",
)
workflow_text = workflow_text.replace(
    "grep -Fq \"versionName='0.3.0-rc.2'\" \"$evidence/badging.txt\"",
    "grep -Fq \"versionName='0.3.0-rc.3'\" \"$evidence/badging.txt\"",
)
if "EXPECTED_APP_VERSION: '0.3.0-rc.3+6'" not in workflow_text:
    raise SystemExit('mobile workflow version anchor missing')
workflow_file.write_text(workflow_text)

feature_dir = mobile / 'lib/features/team'
feature_dir.mkdir(parents=True, exist_ok=True)

api_source = r'''import 'dart:convert';

import 'package:supabase_flutter/supabase_flutter.dart';

typedef PandoraJson = Map<String, dynamic>;

/// The narrow contract consumed by the Team experience.
///
/// Keeping the screen behind this interface makes every state testable while
/// the production implementation remains bound to the signed-in Supabase
/// session. No service-role credential is ever present in the application.
abstract interface class PandoraUserAdminGateway {
  Future<List<PandoraOrganizationAccess>> loadOrganizations();

  Future<List<PandoraTeamMember>> loadMembers(String organizationId);

  Future<PandoraInviteResult> inviteMember(
    String organizationId,
    PandoraInviteRequest request,
  );
}

class SupabasePandoraUserAdminGateway implements PandoraUserAdminGateway {
  SupabasePandoraUserAdminGateway({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  final SupabaseClient _client;

  static const String functionName = 'pandora-user-admin';

  @override
  Future<List<PandoraOrganizationAccess>> loadOrganizations() async {
    final user = _client.auth.currentUser;
    if (user == null) {
      throw const PandoraUserAdminFailure(
        code: 'SIGN_IN_REQUIRED',
        message: 'Sign in to manage your team.',
      );
    }

    try {
      final response = await _client
          .from('memberships')
          .select(
            'organization_id, role, status, created_at, '
            'organizations(name, slug)',
          )
          .eq('user_id', user.id)
          .eq('status', 'active')
          .order('created_at');

      final organizations = <PandoraOrganizationAccess>[];
      for (final value in response) {
        final row = _map(value);
        final role = _string(row['role']);
        if (role != 'owner' && role != 'admin') continue;
        final organization = _map(row['organizations']);
        final id = _string(row['organization_id']);
        if (id == null) continue;
        organizations.add(
          PandoraOrganizationAccess(
            id: id,
            name: _string(organization['name']) ?? 'Organization',
            slug: _string(organization['slug']),
            role: role!,
          ),
        );
      }
      return organizations;
    } on PostgrestException catch (error) {
      throw PandoraUserAdminFailure(
        code: 'ORGANIZATION_LOOKUP_FAILED',
        message: _plainPostgrestMessage(
          error,
          'Pandora could not load your organization access.',
        ),
      );
    } catch (error) {
      if (error is PandoraUserAdminFailure) rethrow;
      throw const PandoraUserAdminFailure(
        code: 'ORGANIZATION_LOOKUP_FAILED',
        message: 'Pandora could not load your organization access.',
      );
    }
  }

  @override
  Future<List<PandoraTeamMember>> loadMembers(String organizationId) async {
    final payload = await _invoke(
      organizationId: organizationId,
      method: HttpMethod.get,
    );
    final rawMembers = payload['members'];
    if (rawMembers is! List) {
      throw const PandoraUserAdminFailure(
        code: 'INVALID_RESPONSE',
        message: 'Pandora received an invalid team response.',
      );
    }
    return rawMembers
        .map((value) => PandoraTeamMember.fromJson(_map(value)))
        .toList(growable: false);
  }

  @override
  Future<PandoraInviteResult> inviteMember(
    String organizationId,
    PandoraInviteRequest request,
  ) async {
    final payload = await _invoke(
      organizationId: organizationId,
      method: HttpMethod.post,
      body: request.toJson(),
    );
    return PandoraInviteResult.fromJson(payload);
  }

  Future<PandoraJson> _invoke({
    required String organizationId,
    required HttpMethod method,
    PandoraJson? body,
  }) async {
    if (_client.auth.currentSession == null) {
      throw const PandoraUserAdminFailure(
        code: 'SIGN_IN_REQUIRED',
        message: 'Sign in to manage your team.',
      );
    }

    try {
      final response = await _client.functions.invoke(
        functionName,
        method: method,
        headers: <String, String>{'x-organization-id': organizationId},
        body: body,
      );
      final payload = _decodeMap(response.data);
      if (response.status < 200 || response.status >= 300) {
        throw PandoraUserAdminFailure.fromPayload(
          payload,
          fallbackCode: 'USER_ADMIN_FAILED',
          fallbackMessage: 'Pandora could not complete the team request.',
        );
      }
      return payload;
    } on FunctionException catch (error) {
      final details = _decodeMap(error.details);
      throw PandoraUserAdminFailure.fromPayload(
        details,
        fallbackCode: 'USER_ADMIN_UNAVAILABLE',
        fallbackMessage: _friendlyFunctionMessage(error),
      );
    } catch (error) {
      if (error is PandoraUserAdminFailure) rethrow;
      throw const PandoraUserAdminFailure(
        code: 'USER_ADMIN_UNAVAILABLE',
        message: 'Team management is temporarily unavailable.',
      );
    }
  }
}

class PandoraOrganizationAccess {
  const PandoraOrganizationAccess({
    required this.id,
    required this.name,
    required this.role,
    this.slug,
  });

  final String id;
  final String name;
  final String role;
  final String? slug;

  bool get isOwner => role == 'owner';
}

class PandoraTeamMember {
  const PandoraTeamMember({
    required this.id,
    required this.role,
    required this.status,
    this.email,
    this.displayName,
    this.invitedBy,
    this.joinedAt,
    this.createdAt,
    this.updatedAt,
  });

  factory PandoraTeamMember.fromJson(PandoraJson json) => PandoraTeamMember(
        id: _string(json['id']) ?? '',
        email: _string(json['email']),
        displayName: _string(json['displayName'] ?? json['display_name']),
        role: _string(json['role']) ?? 'member',
        status: _string(json['status']) ?? 'invited',
        invitedBy: _string(json['invitedBy'] ?? json['invited_by']),
        joinedAt: _date(json['joinedAt'] ?? json['joined_at']),
        createdAt: _date(json['createdAt'] ?? json['created_at']),
        updatedAt: _date(json['updatedAt'] ?? json['updated_at']),
      );

  final String id;
  final String? email;
  final String? displayName;
  final String role;
  final String status;
  final String? invitedBy;
  final DateTime? joinedAt;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  String get primaryLabel {
    final name = displayName?.trim();
    if (name != null && name.isNotEmpty) return name;
    final address = email?.trim();
    if (address != null && address.isNotEmpty) return address;
    return 'Pandora user';
  }

  String get initials {
    final words = primaryLabel
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .take(2)
        .toList(growable: false);
    if (words.isEmpty) return 'P';
    return words.map((word) => word[0].toUpperCase()).join();
  }

  bool get isActive => status == 'active';
  bool get isInvited => status == 'invited';
}

class PandoraInviteRequest {
  const PandoraInviteRequest({
    required this.email,
    required this.role,
    this.displayName,
    this.timezone = 'UTC',
  });

  final String email;
  final String role;
  final String? displayName;
  final String timezone;

  PandoraJson toJson() => <String, dynamic>{
        'email': email.trim().toLowerCase(),
        'displayName': _nullableTrimmed(displayName),
        'timezone': timezone.trim().isEmpty ? 'UTC' : timezone.trim(),
        'role': role,
      };
}

class PandoraInviteResult {
  const PandoraInviteResult({
    required this.userId,
    required this.email,
    required this.role,
    required this.status,
    required this.inviteSent,
    required this.existingAccount,
    this.displayName,
    this.requestId,
  });

  factory PandoraInviteResult.fromJson(PandoraJson json) {
    final user = _map(json['user']);
    final membership = _map(json['membership']);
    return PandoraInviteResult(
      userId: _string(user['id']) ?? '',
      email: _string(user['email']) ?? '',
      displayName: _string(user['displayName'] ?? user['display_name']),
      role: _string(membership['role']) ?? 'member',
      status: _string(membership['status']) ?? 'invited',
      inviteSent: json['inviteSent'] == true,
      existingAccount: json['existingAccount'] == true,
      requestId: _string(json['requestId']),
    );
  }

  final String userId;
  final String email;
  final String? displayName;
  final String role;
  final String status;
  final bool inviteSent;
  final bool existingAccount;
  final String? requestId;
}

class PandoraUserAdminFailure implements Exception {
  const PandoraUserAdminFailure({
    required this.code,
    required this.message,
    this.requestId,
  });

  factory PandoraUserAdminFailure.fromPayload(
    PandoraJson payload, {
    required String fallbackCode,
    required String fallbackMessage,
  }) =>
      PandoraUserAdminFailure(
        code: _string(payload['code']) ?? fallbackCode,
        message: _string(payload['plainMessage'] ?? payload['message']) ??
            fallbackMessage,
        requestId: _string(payload['requestId']),
      );

  final String code;
  final String message;
  final String? requestId;

  bool get isPermissionFailure =>
      code == 'ADMIN_ROLE_REQUIRED' ||
      code == 'OWNER_ROLE_REQUIRED' ||
      code == 'ORGANIZATION_ACCESS_REQUIRED';

  @override
  String toString() => message;
}

PandoraJson _map(Object? value) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) {
    return value.map((key, item) => MapEntry(key.toString(), item));
  }
  return <String, dynamic>{};
}

PandoraJson _decodeMap(Object? value) {
  if (value is String) {
    try {
      return _map(jsonDecode(value));
    } catch (_) {
      return <String, dynamic>{};
    }
  }
  return _map(value);
}

String? _string(Object? value) {
  if (value is! String) return null;
  final normalized = value.trim();
  return normalized.isEmpty ? null : normalized;
}

String? _nullableTrimmed(String? value) {
  final normalized = value?.trim();
  return normalized == null || normalized.isEmpty ? null : normalized;
}

DateTime? _date(Object? value) {
  final raw = _string(value);
  return raw == null ? null : DateTime.tryParse(raw)?.toLocal();
}

String _friendlyFunctionMessage(FunctionException error) {
  if (error.status == 401) return 'Sign in again to manage your team.';
  if (error.status == 403) return 'You do not have permission to manage this team.';
  if (error.status == 429) return 'Too many requests. Try again shortly.';
  return 'Team management is temporarily unavailable.';
}

String _plainPostgrestMessage(PostgrestException error, String fallback) {
  final message = error.message.trim();
  return message.isEmpty ? fallback : fallback;
}
'''
(feature_dir / 'pandora_user_admin_api.dart').write_text(api_source)

screen_source = r'''import 'package:flutter/material.dart';

import '../../core/design/pandora_tokens.dart';
import '../../core/widgets/pandora_page.dart';
import '../../core/widgets/pandora_surface.dart';
import 'pandora_user_admin_api.dart';

class TeamScreen extends StatefulWidget {
  const TeamScreen({super.key, this.gateway});

  final PandoraUserAdminGateway? gateway;

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  late final PandoraUserAdminGateway _gateway;
  List<PandoraOrganizationAccess> _organizations = const [];
  List<PandoraTeamMember> _members = const [];
  String? _selectedOrganizationId;
  PandoraUserAdminFailure? _failure;
  bool _loading = true;
  bool _refreshing = false;
  bool _inviting = false;

  PandoraOrganizationAccess? get _selectedOrganization {
    final id = _selectedOrganizationId;
    if (id == null) return null;
    for (final organization in _organizations) {
      if (organization.id == id) return organization;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    _gateway = widget.gateway ?? SupabasePandoraUserAdminGateway();
    _load(initial: true);
  }

  Future<void> _load({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      if (initial) {
        _loading = true;
      } else {
        _refreshing = true;
      }
      _failure = null;
    });

    try {
      final organizations = await _gateway.loadOrganizations();
      var selected = _selectedOrganizationId;
      if (!organizations.any((organization) => organization.id == selected)) {
        selected = organizations.isEmpty ? null : organizations.first.id;
      }
      final members = selected == null
          ? const <PandoraTeamMember>[]
          : await _gateway.loadMembers(selected);
      if (!mounted) return;
      setState(() {
        _organizations = organizations;
        _selectedOrganizationId = selected;
        _members = members;
      });
    } on PandoraUserAdminFailure catch (failure) {
      if (!mounted) return;
      setState(() => _failure = failure);
    } catch (_) {
      if (!mounted) return;
      setState(
        () => _failure = const PandoraUserAdminFailure(
          code: 'UNKNOWN',
          message: 'Pandora could not load the team right now.',
        ),
      );
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
          _refreshing = false;
        });
      }
    }
  }

  Future<void> _selectOrganization(String? id) async {
    if (id == null || id == _selectedOrganizationId) return;
    setState(() {
      _selectedOrganizationId = id;
      _members = const [];
      _loading = true;
      _failure = null;
    });
    try {
      final members = await _gateway.loadMembers(id);
      if (!mounted || _selectedOrganizationId != id) return;
      setState(() => _members = members);
    } on PandoraUserAdminFailure catch (failure) {
      if (!mounted || _selectedOrganizationId != id) return;
      setState(() => _failure = failure);
    } finally {
      if (mounted && _selectedOrganizationId == id) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _openInvite() async {
    final organization = _selectedOrganization;
    if (organization == null || _inviting) return;
    final request = await showModalBottomSheet<PandoraInviteRequest>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: true,
      builder: (context) => _InviteMemberSheet(isOwner: organization.isOwner),
    );
    if (request == null || !mounted) return;

    setState(() {
      _inviting = true;
      _failure = null;
    });
    try {
      final result = await _gateway.inviteMember(organization.id, request);
      final members = await _gateway.loadMembers(organization.id);
      if (!mounted) return;
      setState(() => _members = members);
      final text = result.inviteSent
          ? 'Invitation sent to ${result.email}.'
          : result.existingAccount
              ? '${result.email} was added to the team.'
              : '${result.email} is ready to join.';
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(text)));
    } on PandoraUserAdminFailure catch (failure) {
      if (!mounted) return;
      setState(() => _failure = failure);
      ScaffoldMessenger.of(context)
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(failure.message)));
    } finally {
      if (mounted) setState(() => _inviting = false);
    }
  }

  @override
  Widget build(BuildContext context) => PandoraPage(
        title: 'Team',
        subtitle: 'Invite people and give each person the access they need.',
        onRefresh: _load,
        actions: [
          IconButton(
            tooltip: 'Refresh team',
            onPressed: _refreshing ? null : _load,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
        child: _buildBody(context),
      );

  Widget _buildBody(BuildContext context) {
    if (_loading && _organizations.isEmpty) {
      return const _TeamLoadingState();
    }

    if (_failure?.isPermissionFailure == true ||
        (!_loading && _organizations.isEmpty && _failure == null)) {
      return _NoTeamAccessState(onRetry: () => _load(initial: true));
    }

    if (_failure != null && _organizations.isEmpty) {
      return _TeamFailureState(
        failure: _failure!,
        onRetry: () => _load(initial: true),
      );
    }

    final organization = _selectedOrganization;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
          if (_organizations.length > 1) ...[
            PandoraSurface(
              title: 'Organization',
              child: DropdownButtonFormField<String>(
                initialValue: _selectedOrganizationId,
                decoration: const InputDecoration(
                  labelText: 'Manage team for',
                  prefixIcon: Icon(Icons.business_outlined),
                ),
                items: _organizations
                    .map(
                      (item) => DropdownMenuItem<String>(
                        value: item.id,
                        child: Text(item.name),
                      ),
                    )
                    .toList(growable: false),
                onChanged: _selectOrganization,
              ),
            ),
            const SizedBox(height: PandoraSpacing.md),
          ],
          _TeamSummary(
            organization: organization,
            members: _members,
            inviting: _inviting,
            refreshing: _refreshing,
            onInvite: _openInvite,
          ),
          if (_failure != null) ...[
            const SizedBox(height: PandoraSpacing.md),
            _InlineFailure(failure: _failure!, onRetry: _load),
          ],
          const SizedBox(height: PandoraSpacing.md),
          PandoraSurface(
            title: 'People',
            subtitle: _members.isEmpty
                ? 'The people who can use this Pandora organization appear here.'
                : '${_members.length} ${_members.length == 1 ? 'person' : 'people'}',
            child: _loading
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: PandoraSpacing.lg),
                    child: Center(child: CircularProgressIndicator()),
                  )
                : _members.isEmpty
                    ? _EmptyTeamState(onInvite: _openInvite)
                    : Column(
                        children: [
                          for (var index = 0;
                              index < _members.length;
                              index++) ...[
                            _MemberTile(member: _members[index]),
                            if (index != _members.length - 1)
                              const Divider(height: 1),
                          ],
                        ],
                      ),
          ),
        const SizedBox(height: PandoraSpacing.lg),
      ],
    );
  }
}

class _TeamSummary extends StatelessWidget {
  const _TeamSummary({
    required this.organization,
    required this.members,
    required this.inviting,
    required this.refreshing,
    required this.onInvite,
  });

  final PandoraOrganizationAccess? organization;
  final List<PandoraTeamMember> members;
  final bool inviting;
  final bool refreshing;
  final VoidCallback onInvite;

  @override
  Widget build(BuildContext context) {
    final active = members.where((member) => member.isActive).length;
    final invited = members.where((member) => member.isInvited).length;
    return PandoraSurface(
      title: organization?.name ?? 'Your team',
      subtitle: organization == null
          ? 'Organization access is being checked.'
          : 'You are an ${_roleLabel(organization!.role).toLowerCase()}.',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: PandoraSpacing.sm,
            runSpacing: PandoraSpacing.sm,
            children: [
              _Metric(label: 'Active', value: '$active'),
              _Metric(label: 'Invited', value: '$invited'),
              _Metric(label: 'Total', value: '${members.length}'),
            ],
          ),
          const SizedBox(height: PandoraSpacing.md),
          FilledButton.icon(
            onPressed: organization == null || inviting ? null : onInvite,
            icon: inviting
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.person_add_alt_1_rounded),
            label: Text(inviting ? 'Adding person…' : 'Add person'),
          ),
          if (refreshing) ...[
            const SizedBox(height: PandoraSpacing.sm),
            const LinearProgressIndicator(),
          ],
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Semantics(
        label: '$label: $value',
        child: Container(
          constraints: const BoxConstraints(minWidth: 92),
          padding: const EdgeInsets.symmetric(
            horizontal: PandoraSpacing.md,
            vertical: PandoraSpacing.sm,
          ),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: Theme.of(context).textTheme.headlineSmall),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      );
}

class _MemberTile extends StatelessWidget {
  const _MemberTile({required this.member});

  final PandoraTeamMember member;

  @override
  Widget build(BuildContext context) {
    final statusColor = member.isActive
        ? Theme.of(context).colorScheme.primary
        : Theme.of(context).colorScheme.tertiary;
    return Semantics(
      container: true,
      label:
          '${member.primaryLabel}, ${_roleLabel(member.role)}, ${_statusLabel(member.status)}',
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: PandoraSpacing.xs),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(child: Text(member.initials)),
            const SizedBox(width: PandoraSpacing.sm),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    member.primaryLabel,
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  if (member.displayName != null && member.email != null)
                    Text(
                      member.email!,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  const SizedBox(height: PandoraSpacing.xxs),
                  Wrap(
                    spacing: PandoraSpacing.xs,
                    runSpacing: PandoraSpacing.xxs,
                    children: [
                      _Tag(label: _roleLabel(member.role)),
                      _Tag(
                        label: _statusLabel(member.status),
                        foreground: statusColor,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag({required this.label, this.foreground});

  final String label;
  final Color? foreground;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: (foreground ?? Theme.of(context).colorScheme.onSurface)
              .withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                color: foreground,
                fontWeight: FontWeight.w600,
              ),
        ),
      );
}

class _InviteMemberSheet extends StatefulWidget {
  const _InviteMemberSheet({required this.isOwner});

  final bool isOwner;

  @override
  State<_InviteMemberSheet> createState() => _InviteMemberSheetState();
}

class _InviteMemberSheetState extends State<_InviteMemberSheet> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _nameController = TextEditingController();
  final _timezoneController = TextEditingController(text: 'UTC');
  String _role = 'member';

  List<String> get _roles => widget.isOwner
      ? const ['admin', 'operator', 'member', 'viewer']
      : const ['operator', 'member', 'viewer'];

  @override
  void dispose() {
    _emailController.dispose();
    _nameController.dispose();
    _timezoneController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.of(context).pop(
      PandoraInviteRequest(
        email: _emailController.text,
        displayName: _nameController.text,
        timezone: _timezoneController.text,
        role: _role,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(
        PandoraSpacing.lg,
        PandoraSpacing.sm,
        PandoraSpacing.lg,
        PandoraSpacing.lg + bottom,
      ),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Add a person', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: PandoraSpacing.xs),
            Text(
              'Pandora will send an invitation and apply the selected access after the person confirms their email.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: PandoraSpacing.lg),
            TextFormField(
              controller: _emailController,
              autofocus: true,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Email address',
                hintText: 'person@example.com',
                prefixIcon: Icon(Icons.alternate_email_rounded),
              ),
              validator: (value) {
                final email = value?.trim() ?? '';
                if (email.isEmpty) return 'Enter an email address.';
                if (!RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(email)) {
                  return 'Enter a valid email address.';
                }
                return null;
              },
            ),
            const SizedBox(height: PandoraSpacing.md),
            TextFormField(
              controller: _nameController,
              textCapitalization: TextCapitalization.words,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Name (optional)',
                prefixIcon: Icon(Icons.person_outline_rounded),
              ),
              validator: (value) => (value?.trim().length ?? 0) > 120
                  ? 'Keep the name under 120 characters.'
                  : null,
            ),
            const SizedBox(height: PandoraSpacing.md),
            DropdownButtonFormField<String>(
              initialValue: _role,
              decoration: const InputDecoration(
                labelText: 'Access',
                prefixIcon: Icon(Icons.admin_panel_settings_outlined),
              ),
              items: _roles
                  .map(
                    (role) => DropdownMenuItem<String>(
                      value: role,
                      child: Text(_roleLabel(role)),
                    ),
                  )
                  .toList(growable: false),
              onChanged: (value) => setState(() => _role = value ?? 'member'),
            ),
            const SizedBox(height: PandoraSpacing.md),
            TextFormField(
              controller: _timezoneController,
              textInputAction: TextInputAction.done,
              onFieldSubmitted: (_) => _submit(),
              decoration: const InputDecoration(
                labelText: 'Timezone',
                helperText: 'Used for activity times and notifications.',
                prefixIcon: Icon(Icons.schedule_rounded),
              ),
              validator: (value) {
                final timezone = value?.trim() ?? '';
                if (timezone.isEmpty) return 'Enter a timezone or use UTC.';
                if (timezone.length > 64) return 'Keep the timezone under 64 characters.';
                return null;
              },
            ),
            const SizedBox(height: PandoraSpacing.lg),
            FilledButton.icon(
              onPressed: _submit,
              icon: const Icon(Icons.send_rounded),
              label: const Text('Send invitation'),
            ),
            const SizedBox(height: PandoraSpacing.sm),
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
          ],
        ),
      ),
    );
  }
}

class _TeamLoadingState extends StatelessWidget {
  const _TeamLoadingState();

  @override
  Widget build(BuildContext context) => const Padding(
        padding: EdgeInsets.symmetric(vertical: 72),
        child: Center(child: CircularProgressIndicator()),
      );
}

class _EmptyTeamState extends StatelessWidget {
  const _EmptyTeamState({required this.onInvite});

  final VoidCallback onInvite;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: PandoraSpacing.lg),
        child: Column(
          children: [
            Icon(
              Icons.group_add_outlined,
              size: 48,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
            const SizedBox(height: PandoraSpacing.sm),
            Text('No one has been added yet.',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: PandoraSpacing.xs),
            Text(
              'Add the first person and choose what they can access.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: PandoraSpacing.md),
            OutlinedButton.icon(
              onPressed: onInvite,
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('Add person'),
            ),
          ],
        ),
      );
}

class _InlineFailure extends StatelessWidget {
  const _InlineFailure({required this.failure, required this.onRetry});

  final PandoraUserAdminFailure failure;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) => Material(
        color: Theme.of(context).colorScheme.errorContainer,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(PandoraSpacing.md),
          child: Row(
            children: [
              Icon(
                Icons.info_outline_rounded,
                color: Theme.of(context).colorScheme.onErrorContainer,
              ),
              const SizedBox(width: PandoraSpacing.sm),
              Expanded(
                child: Text(
                  failure.message,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onErrorContainer,
                  ),
                ),
              ),
              TextButton(onPressed: onRetry, child: const Text('Retry')),
            ],
          ),
        ),
      );
}

class _TeamFailureState extends StatelessWidget {
  const _TeamFailureState({required this.failure, required this.onRetry});

  final PandoraUserAdminFailure failure;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => PandoraSurface(
        title: 'Team is temporarily unavailable',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(failure.message),
            if (failure.requestId != null) ...[
              const SizedBox(height: PandoraSpacing.xs),
              SelectableText(
                'Reference: ${failure.requestId}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
            const SizedBox(height: PandoraSpacing.md),
            FilledButton.tonalIcon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Try again'),
            ),
          ],
        ),
      );
}

class _NoTeamAccessState extends StatelessWidget {
  const _NoTeamAccessState({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) => PandoraSurface(
        title: 'Owner or administrator access required',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Only an active organization owner or administrator can invite people or view the team directory.',
            ),
            const SizedBox(height: PandoraSpacing.md),
            OutlinedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Check access again'),
            ),
          ],
        ),
      );
}

String _roleLabel(String role) => switch (role) {
      'owner' => 'Owner',
      'admin' => 'Administrator',
      'operator' => 'Operator',
      'viewer' => 'Viewer',
      _ => 'Member',
    };

String _statusLabel(String status) => switch (status) {
      'active' => 'Active',
      'invited' => 'Invited',
      'suspended' => 'Suspended',
      'revoked' => 'Revoked',
      _ => status,
    };
'''
(feature_dir / 'team_screen.dart').write_text(screen_source)

# Integrate Team into the owner-facing More screen and keep the gateway
# injectable so navigation is covered without touching the live provider.
more = mobile / 'lib/features/simple/more_screen.dart'
text = more.read_text()
api_import = "import '../team/pandora_user_admin_api.dart';\n"
screen_import = "import '../team/team_screen.dart';\n"
if api_import not in text or screen_import not in text:
    anchor = "import '../settings/settings_screen.dart';\n"
    if anchor not in text:
        raise SystemExit('MoreScreen settings import anchor missing')
    imports = ''.join(
        value for value in (api_import, screen_import) if value not in text
    )
    text = text.replace(anchor, anchor + imports, 1)

class_anchor = "class MoreScreen extends StatelessWidget {\n  const MoreScreen({super.key});\n"
if class_anchor in text:
    text = text.replace(
        class_anchor,
        "class MoreScreen extends StatelessWidget {\n"
        "  const MoreScreen({super.key, this.teamGateway});\n\n"
        "  final PandoraUserAdminGateway? teamGateway;\n",
        1,
    )
elif 'final PandoraUserAdminGateway? teamGateway;' not in text:
    raise SystemExit('MoreScreen constructor anchor missing')

if "title: 'Team'" not in text:
    account_pattern = re.compile(
        r"(\s+PandoraSurface\(\n\s+title: 'Account',\n)"
        r"(\s+child: _MoreTile\(\n"
        r"\s+icon: Icons\.settings_outlined,\n"
        r"\s+title: 'Settings',\n"
        r"\s+subtitle: 'Appearance, account, security, and app identity',\n"
        r"\s+onTap: \(\) => _openMore\(context, const SettingsScreen\(\)\),\n"
        r"\s+\),\n)"
        r"(\s+\),)",
        re.M,
    )
    match = account_pattern.search(text)
    if not match:
        raise SystemExit('MoreScreen Account surface anchor missing')
    indent = ' ' * 14
    replacement = (
        match.group(1)
        + f"{indent}child: Column(\n"
        + f"{indent}  children: [\n"
        + f"{indent}    _MoreTile(\n"
        + f"{indent}      icon: Icons.groups_outlined,\n"
        + f"{indent}      title: 'Team',\n"
        + f"{indent}      subtitle: 'Invite people and manage their access',\n"
        + f"{indent}      onTap: () => _openMore(\n"
        + f"{indent}        context,\n"
        + f"{indent}        TeamScreen(gateway: teamGateway),\n"
        + f"{indent}      ),\n"
        + f"{indent}    ),\n"
        + f"{indent}    _MoreTile(\n"
        + f"{indent}      icon: Icons.settings_outlined,\n"
        + f"{indent}      title: 'Settings',\n"
        + f"{indent}      subtitle: 'Appearance, account, security, and app identity',\n"
        + f"{indent}      onTap: () => _openMore(context, const SettingsScreen()),\n"
        + f"{indent}    ),\n"
        + f"{indent}  ],\n"
        + f"{indent}),\n"
        + match.group(3)
    )
    text = text[:match.start()] + replacement + text[match.end():]
more.write_text(text)

# Contract/model tests are deterministic and do not need a live Supabase session.
test_dir = mobile / 'test/features/team'
test_dir.mkdir(parents=True, exist_ok=True)
model_test = f'''import 'package:flutter_test/flutter_test.dart';
import 'package:{package_name}/features/team/pandora_user_admin_api.dart';

void main() {{
  group('Pandora team models', () {{
    test('normalizes member payloads and presentation labels', () {{
      final member = PandoraTeamMember.fromJson(<String, dynamic>{{
        'id': '11111111-1111-4111-8111-111111111111',
        'email': 'person@example.com',
        'displayName': 'Ada Lovelace',
        'role': 'operator',
        'status': 'active',
        'joinedAt': '2026-08-26T00:00:00Z',
      }});

      expect(member.primaryLabel, 'Ada Lovelace');
      expect(member.initials, 'AL');
      expect(member.isActive, isTrue);
      expect(member.isInvited, isFalse);
      expect(member.joinedAt, isNotNull);
    }});

    test('invite payload trims values without adding authority', () {{
      const request = PandoraInviteRequest(
        email: ' PERSON@EXAMPLE.COM ',
        displayName: ' Person Name ',
        timezone: ' Asia/Manila ',
        role: 'member',
      );

      expect(request.toJson(), <String, dynamic>{{
        'email': 'person@example.com',
        'displayName': 'Person Name',
        'timezone': 'Asia/Manila',
        'role': 'member',
      }});
    }});

    test('maps safe backend failure fields', () {{
      final failure = PandoraUserAdminFailure.fromPayload(
        <String, dynamic>{{
          'code': 'ROLE_GRANT_NOT_ALLOWED',
          'plainMessage': 'Only an owner can grant this role.',
          'requestId': 'request-123',
        }},
        fallbackCode: 'FAILED',
        fallbackMessage: 'Failed.',
      );

      expect(failure.code, 'ROLE_GRANT_NOT_ALLOWED');
      expect(failure.message, 'Only an owner can grant this role.');
      expect(failure.requestId, 'request-123');
    }});
  }});
}}
'''
(test_dir / 'pandora_user_admin_api_test.dart').write_text(model_test)

widget_test = f'''import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:{package_name}/features/team/pandora_user_admin_api.dart';
import 'package:{package_name}/features/simple/more_screen.dart';
import 'package:{package_name}/features/team/team_screen.dart';

class _FakeGateway implements PandoraUserAdminGateway {{
  final organizations = const <PandoraOrganizationAccess>[
    PandoraOrganizationAccess(
      id: '11111111-1111-4111-8111-111111111111',
      name: 'Banatao Systems',
      role: 'owner',
    ),
  ];

  var members = const <PandoraTeamMember>[
    PandoraTeamMember(
      id: '22222222-2222-4222-8222-222222222222',
      displayName: 'Mark Johnson',
      email: 'owner@example.com',
      role: 'owner',
      status: 'active',
    ),
  ];

  PandoraInviteRequest? lastInvite;

  @override
  Future<List<PandoraOrganizationAccess>> loadOrganizations() async =>
      organizations;

  @override
  Future<List<PandoraTeamMember>> loadMembers(String organizationId) async =>
      members;

  @override
  Future<PandoraInviteResult> inviteMember(
    String organizationId,
    PandoraInviteRequest request,
  ) async {{
    lastInvite = request;
    members = <PandoraTeamMember>[
      ...members,
      PandoraTeamMember(
        id: '33333333-3333-4333-8333-333333333333',
        displayName: request.displayName,
        email: request.email,
        role: request.role,
        status: 'invited',
      ),
    ];
    return PandoraInviteResult(
      userId: '33333333-3333-4333-8333-333333333333',
      email: request.email,
      displayName: request.displayName,
      role: request.role,
      status: 'invited',
      inviteSent: true,
      existingAccount: false,
    );
  }}
}}

void main() {{
  testWidgets('owner can invite a person and refresh the team list',
      (tester) async {{
    final gateway = _FakeGateway();
    await tester.pumpWidget(
      MaterialApp(home: TeamScreen(gateway: gateway)),
    );
    await tester.pumpAndSettle();

    expect(find.text('Team'), findsOneWidget);
    expect(find.text('Mark Johnson'), findsOneWidget);
    expect(find.text('Add person'), findsOneWidget);

    await tester.tap(find.text('Add person').first);
    await tester.pumpAndSettle();
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Email address'),
      'new.person@example.com',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Name (optional)'),
      'New Person',
    );
    await tester.tap(find.text('Send invitation'));
    await tester.pumpAndSettle();

    expect(gateway.lastInvite?.email, 'new.person@example.com');
    expect(find.text('New Person'), findsOneWidget);
    expect(find.text('Invited'), findsWidgets);
    expect(find.text('Invitation sent to new.person@example.com.'), findsOneWidget);
  }});

  testWidgets('More account navigation opens the real Team screen',
      (tester) async {{
    final gateway = _FakeGateway();
    await tester.pumpWidget(
      MaterialApp(home: MoreScreen(teamGateway: gateway)),
    );
    await tester.pumpAndSettle();

    expect(find.text('Team'), findsOneWidget);
    await tester.tap(find.text('Team'));
    await tester.pumpAndSettle();

    expect(find.text('Invite people and give each person the access they need.'),
        findsOneWidget);
    expect(find.text('Mark Johnson'), findsOneWidget);
  }});
}}
'''
(test_dir / 'team_screen_test.dart').write_text(widget_test)

# A concise integration guide belongs with the feature and keeps the endpoint contract explicit.
docs = ROOT / 'docs/product'
docs.mkdir(parents=True, exist_ok=True)
(docs / 'PANDORA_TEAM_USER_MANAGEMENT.md').write_text(r'''# Pandora Team and User Management

## Product surface

The owner-facing **More → Team** screen is the canonical mobile entry point for
organization user administration. It discovers active owner/admin memberships
from the signed-in Supabase session and never asks an ordinary owner to enter an
organization UUID.

The screen provides:

- active and invited member counts;
- organization selection when the owner manages more than one organization;
- member name, email, role, and status;
- role-aware invitations;
- loading, empty, permission-denied, degraded, retry, and success states;
- pull-to-refresh and post-invitation readback.

## Runtime contract

The mobile gateway invokes the deployed `pandora-user-admin` Supabase Edge
Function with the current user JWT and an `x-organization-id` header.

- `GET /functions/v1/pandora-user-admin` lists organization members.
- `POST /functions/v1/pandora-user-admin` creates or finds the Auth account,
  sends an invitation when needed, and creates the governed membership.

The browser or APK never receives the Supabase service-role key. The Edge
Function validates the caller as an active owner/admin and invokes the
service-only membership broker. Owners can grant elevated roles; administrators
cannot grant owner or administrator authority.

## Required environment

- Supabase project: `jcyqixttuebxqqfkjonq`
- Edge Function: `pandora-user-admin`
- Optional server secret: `PANDORA_INVITE_REDIRECT_URL`
- Optional server secret: `PANDORA_ALLOWED_ORIGINS`

No credential belongs in Flutter source, GitHub documentation, or semantic
memory.
''')

# Make sure the new function is included in Supabase type checking if the script exists.
package_json = ROOT / 'package.json'
if package_json.exists():
    pj = package_json.read_text()
    marker = 'supabase/functions/pandora-owner-api/index.ts'
    addition = 'supabase/functions/pandora-user-admin/index.ts '
    if addition.strip() not in pj and marker in pj:
        pj = pj.replace(marker, addition + marker, 1)
        package_json.write_text(pj)

# Ensure config declares JWT verification.
config = ROOT / 'supabase/config.toml'
if config.exists():
    cfg = config.read_text()
    if '[functions.pandora-user-admin]' not in cfg:
        cfg = '[functions.pandora-user-admin]\nverify_jwt = true\n\n' + cfg
        config.write_text(cfg)

# Add a source-level contract test to the root Node suite even when Flutter is unavailable.
root_test = ROOT / 'test/pandora-team-mobile-contract.test.js'
root_test.write_text(r'''import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const api = readFileSync(
  'apps/pandora-mobile/lib/features/team/pandora_user_admin_api.dart',
  'utf8',
);
const screen = readFileSync(
  'apps/pandora-mobile/lib/features/team/team_screen.dart',
  'utf8',
);
const more = readFileSync(
  'apps/pandora-mobile/lib/features/simple/more_screen.dart',
  'utf8',
);
const fn = readFileSync(
  'supabase/functions/pandora-user-admin/index.ts',
  'utf8',
);

test('mobile client uses signed-in function invocation without embedded service role', () => {
  assert.match(api, /Supabase\.instance\.client/);
  assert.match(api, /x-organization-id/);
  assert.match(api, /functionName = 'pandora-user-admin'/);
  assert.doesNotMatch(api, /SERVICE_ROLE_KEY|service_role/i);
});

test('Team screen exposes real invite and member states', () => {
  assert.match(screen, /loadOrganizations\(\)/);
  assert.match(screen, /loadMembers\(/);
  assert.match(screen, /inviteMember\(/);
  assert.match(screen, /Owner or administrator access required/);
  assert.match(screen, /No one has been added yet/);
  assert.match(screen, /Invitation sent to/);
});

test('normal owner navigation includes Team', () => {
  assert.match(more, /title: 'Team'/);
  assert.match(more, /TeamScreen\(gateway: teamGateway\)/);
});

test('server authority remains in the Edge Function', () => {
  assert.match(fn, /SUPABASE_SERVICE_ROLE_KEY/);
  assert.match(fn, /auth\.admin\.inviteUserByEmail/);
  assert.match(fn, /pandora_admin_add_organization_member/);
  assert.match(fn, /ADMIN_ROLE_REQUIRED/);
});
''')

# Remove one-shot delivery machinery and obsolete self-mutating diagnostics
# before the exact tested source is committed.
for relative_path in (
    '.github/workflows/pandora-mobile-syntax-diagnostic.yml',
    '.github/workflows/pandora-mobile-ui-debug.yml',
    '.github/workflows/pandora-team-bootstrap.yml',
    'scripts/pandora_team_bootstrap.py',
    'scripts/pandora-user-admin-source-parity.patch',
    'scripts/pandora-team-bootstrap.zip',
):
    candidate = ROOT / relative_path
    if candidate.exists():
        candidate.unlink()

# Write a machine-readable manifest before formatting/verification.
changed = subprocess.run(
    ['git', 'status', '--short'], cwd=ROOT, capture_output=True, text=True, check=True
).stdout.splitlines()
manifest_dir = ROOT / 'docs/evidence'
manifest_dir.mkdir(parents=True, exist_ok=True)
(manifest_dir / 'pandora_team_implementation_manifest.json').write_text(json.dumps({
    'package': package_name,
    'app_version': '0.3.0-rc.3+6',
    'supabase_project': 'jcyqixttuebxqqfkjonq',
    'edge_function': 'pandora-user-admin',
    'changed_files_before_format': changed,
}, indent=2))
